package es.adri.proyectoreservas_adrianrodriguez.Pruebas;

import es.adri.proyectoreservas_adrianrodriguez.Entidades.Reserva;
import es.adri.proyectoreservas_adrianrodriguez.Repositorio.ReservaDAO;
import es.adri.proyectoreservas_adrianrodriguez.Repositorio.ReservaDAOImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ProbarSpring {
    public static void main(String[] args) {
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("configuracion_spring.xml");
        ReservaDAO reservaDAO = (ReservaDAOImpl) applicationContext.getBean("reservaDAOImpl");
        Reserva reserva3 = (Reserva) applicationContext.getBean("reserva");

        ((ClassPathXmlApplicationContext) applicationContext).close();
    }
}
