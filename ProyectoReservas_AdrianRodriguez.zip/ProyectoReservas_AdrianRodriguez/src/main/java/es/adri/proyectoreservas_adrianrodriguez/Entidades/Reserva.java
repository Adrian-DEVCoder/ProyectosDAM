package es.adri.proyectoreservas_adrianrodriguez.Entidades;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "RESERVAS")
public class Reserva {

    @Id
    private long idReserva;
    private String nombre;
    private String apellidos;
    private String sexo;
    private String comidas;
    private String procedencia;
    private String destino;

    public Reserva() {
    }

    public Reserva(long idReserva, String nombre, String apellidos, String sexo, String comidas, String procedencia, String destino) {
        this.idReserva = idReserva;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.sexo = sexo;
        this.comidas = comidas;
        this.procedencia = procedencia;
        this.destino = destino;
    }

    public long getIdReserva() {
        return idReserva;
    }

    public void setIdReserva(long idReserva) {
        this.idReserva = idReserva;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getComidas() {
        return comidas;
    }

    public void setComidas(String comidas) {
        this.comidas = comidas;
    }

    public String getProcedencia() {
        return procedencia;
    }

    public void setProcedencia(String procedencia) {
        this.procedencia = procedencia;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }
}
