package es.adri.proyectoreservas_adrianrodriguez.Pruebas;

import es.adri.proyectoreservas_adrianrodriguez.Entidades.Reserva;
import es.adri.proyectoreservas_adrianrodriguez.Repositorio.ReservaDAO;
import es.adri.proyectoreservas_adrianrodriguez.Repositorio.ReservaDAOImpl;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class ProbarDAO {
    public static void main(String[] args) {
        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("upAdrian");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        // Instanciamos el DAO
        ReservaDAO reservaDAO = new ReservaDAOImpl();
        // Instanciamos Reservas
        Reserva reserva1 = new Reserva();
        reserva1.setIdReserva(1L);
        reserva1.setNombre("Pepe");
        reserva1.setApellidos("Pérez");
        reserva1.setComidas("Desayuno");
        reserva1.setSexo("Hombre");
        reserva1.setProcedencia("Madrid");
        reserva1.setDestino("Barcelona");
        Reserva reserva2 = new Reserva();
        reserva2.setIdReserva(2L);
        reserva2.setNombre("Pepa");
        reserva2.setApellidos("Pérez");
        reserva2.setComidas("Desayuno");
        reserva2.setSexo("Mujer");
        reserva2.setProcedencia("Madrid");
        reserva2.setDestino("Barcelona");
        // Insertamos la reserva
        reservaDAO.insertarReserva(reserva1);
        reservaDAO.insertarReserva(reserva2);
        // Mostramos las reservas insertadas
        reservaDAO.getAlLReservas().forEach(reserva ->{
            System.out.println(reserva);
        });
        // Cerramos los entity manager
        entityManager.close();
        entityManagerFactory.close();
    }
}
