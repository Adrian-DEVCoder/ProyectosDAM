package es.adri.proyectoreservas_adrianrodriguez.Repositorio;

import es.adri.proyectoreservas_adrianrodriguez.Entidades.Reserva;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ReservaDAOImpl implements ReservaDAO{

    EntityManagerFactory entityManagerFactory;
    EntityManager entityManager;
    String unidadPersistencia = "upAdrian";

    public ReservaDAOImpl() {
        entityManagerFactory = Persistence.createEntityManagerFactory(unidadPersistencia);
    }

    @Override
    public boolean insertarReserva(Reserva reserva) {
        entityManager = entityManagerFactory.createEntityManager();
        try{
            entityManager.getTransaction().begin();
            entityManager.persist(reserva);
            entityManager.getTransaction().commit();
            return true;
        } catch (Exception exception){
            return false;
        }
    }

    @Override
    public List<Reserva> getAlLReservas() {
        entityManager = entityManagerFactory.createEntityManager();
        String hql = "FROM RESERVAS r";
        Query query = entityManager.createQuery(hql);
        return query.getResultList();
    }

    @Override
    public Reserva getReserva(long id) {
        entityManager = entityManagerFactory.createEntityManager();
        return entityManager.find(Reserva.class, id);
    }
}
