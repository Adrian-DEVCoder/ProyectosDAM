package es.adri.proyectoreservas_adrianrodriguez.Repositorio;

import es.adri.proyectoreservas_adrianrodriguez.Entidades.Reserva;
import org.springframework.stereotype.Component;

import java.util.List;

public interface ReservaDAO {

    public boolean insertarReserva(Reserva reserva);
    public List<Reserva> getAlLReservas();
    public Reserva getReserva(long id);
}
